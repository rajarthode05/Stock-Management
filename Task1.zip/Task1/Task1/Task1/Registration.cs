﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;


namespace Task1
{
    public partial class Registration : Form
    {
        string str1 = ConfigurationManager.ConnectionStrings["str"].ConnectionString;
        public Registration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (user_name.Text==""|| first_name.Text==""||last_name.Text==""||password.Text==""||conforpass.Text==""||email.Text=="")
            {
                MessageBox.Show("field mandetory");
            }
            else
            {
                SqlConnection con = new SqlConnection(str1);
                con.Open();
                SqlCommand cmd = new SqlCommand("insert into registration(user_name1,first_name ,last_name,pass,conformpass,email,gender) values('" + user_name.Text + "','" + first_name.Text + "','" + last_name.Text + "','" + password.Text + "','" + conforpass.Text + "','" + email.Text + "','" + radioButton1.Text + "')", con);
                SqlCommand cmd1 = new SqlCommand("Select * from registration where email='"+email.Text+"'", con);
                int c = 0;
                SqlDataReader dr = cmd1.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        c = 1;
                        MessageBox.Show(" Already Registered");
                        email.Clear();
                        break;
                    }

                }
                dr.Close();
                if (c == 0)
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Successfully registerd");
                     
                }

                
                con.Close();
            }
        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }
    }
}
