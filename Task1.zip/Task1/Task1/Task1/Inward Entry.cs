﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Task1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submit_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-VK41V1R\SQLEXPRESS;Initial Catalog=mylinc;Integrated Security=True");
            con.Open();
            SqlCommand cmd=new SqlCommand("insert into legrand_mylinc values('"+description.Text+"','"+opening_qty.Text+"','"+unit.Text+"')",con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Saved Successfully.....");
            con.Close();
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

            date_tb.Text = DateTime.Now.ToString("dd/MM/yyyy");
            time_tb.Text = DateTime.Now.ToLongTimeString();
        }

        private void delete_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
