﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Task1
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void inwardEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 obj = new Form1();
            obj.Show();
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stock obj = new Stock();
            obj.Show();
        }

        private void outboundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            outward_entry obj = new outward_entry();
            obj.Show();
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OutWard_History obj = new OutWard_History();
            obj.Show();

        }

        private void unitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Unit_setting obj = new Unit_setting();
            obj.Show();
        }

        private void manufacturerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            manufacturar_setting obj = new manufacturar_setting();
            obj.Show();
        }
    }
}
