﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace Task1
{
    public partial class Backup : Form
    {
        string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;
       
        public Backup()
        {
            InitializeComponent();
        }

        private void browse_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = dlg.SelectedPath;
            }
        }


        private void btn_backup_Click(object sender, EventArgs e)
        {
            Backup1();
        }
        private void Backup1()
        {
           try
           {
               MySqlConnection con = new MySqlConnection(str1);
               string file = textBox1.Text + "\\" + "stock_db.bak";
               using (MySqlConnection conn = new MySqlConnection(str1))
               {
                   using (MySqlCommand cmd = new MySqlCommand())
                   {
                       using (MySqlBackup mb = new MySqlBackup(cmd))
                       {
                           cmd.Connection = conn;
                           conn.Open();
                           mb.ExportToFile(file);
                           conn.Close();
                       }
                   }
                   MessageBox.Show("Backup done successfully......");
               }
           }
           catch
           {
               MessageBox.Show("Select Proper path");
           }
            
           
        }

        private void Backup_Load(object sender, EventArgs e)
        {
             string[] passedInArgs = Environment.GetCommandLineArgs();
             if ((passedInArgs.Contains("/h") || passedInArgs.Contains("/H")))
              {
                  MessageBox.Show("You got help");
              }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
