﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions; 

namespace Task1
{
    public partial class Registration : Form
    {
        string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;
        public Registration()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (user_name.Text==""|| first_name.Text==""||last_name.Text==""||password.Text==""||conforpass.Text==""||email.Text=="")
            //{
            //    MessageBox.Show("field mandetory");
            //}

            if (!Regex.IsMatch(first_name.Text.ToString().Trim(), @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("Please Enter Proper First Name");
                first_name.Focus();

            }
            else if (!Regex.IsMatch(last_name.Text.ToString().Trim(), @"^[a-zA-Z]+$"))
            {
                MessageBox.Show("Please Enter Proper Last Name");
                last_name.Focus();
                return;

            }

            else if (!Regex.IsMatch(user_name.Text.ToString().Trim(), @"^(?=[a-zA-Z])[-\w.]{0,23}([a-zA-Z\d]|(?<![-.])_)$"))
            {
                MessageBox.Show("Please Enter Proper User Name");
                user_name.Focus();
                return;

            }

            else if (!Regex.IsMatch(email.Text.ToString().Trim(), @"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$"))
            {
                MessageBox.Show("Please Enter Proper Email Address");
                email.Focus();
                return;

            }

            else if (!Regex.IsMatch(password.Text.ToString().Trim(), @"^.*(?=.{8,})(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!*@#$%^&+=]).*$"))
            {
                MessageBox.Show("Password Must have least 8 characters length with one lower case letter ,one upper case letter,special character , one number.  ");
                password.Focus();
                return;

            }
            else if (password.Text.ToString().Trim() != conforpass.Text.ToString().Trim())
            {
                MessageBox.Show("Password and Confirm Password Does Not Matches");
                return;


            }
            else if (rdb_male.Checked == false && rdb_female.Checked == false)
            {

                MessageBox.Show("Please Select User Gender.");
                return;

            }

            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_registration", con);
                cmd.CommandType = CommandType.StoredProcedure;

                if (button1.Text == "Save")
                {

                    cmd.Parameters.AddWithValue("@flag", 1);
                    cmd.Parameters.AddWithValue("@user_reg_id1", null);

                }
                if (button1.Text == "Update")
                {

                    cmd.Parameters.AddWithValue("@flag", 3);
                    cmd.Parameters.AddWithValue("@user_reg_id1", resigration_id.Text.ToString().Trim());

                }

                cmd.Parameters.AddWithValue("@user_name2", user_name.Text.ToString().Trim());
                cmd.Parameters.AddWithValue("@first_name1", first_name.Text.ToString().Trim());
                cmd.Parameters.AddWithValue("@last_name1", last_name.Text.ToString().Trim());
                cmd.Parameters.AddWithValue("@pass1", password.Text.ToString().Trim());
                cmd.Parameters.AddWithValue("@conformpass1", conforpass.Text.ToString().Trim());
                cmd.Parameters.AddWithValue("@email1", email.Text.ToString().Trim());
                if (rdb_male.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@gender1", rdb_male.Text.ToString().Trim());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@gender1", rdb_female.Text.ToString().Trim());
                }


                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully registerd");
                grid_bind();
                ClearAllControl();
                con.Close();
            }
        }

        private void Registration_Load(object sender, EventArgs e)
        {
            grid_bind();
        }

         
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void grid_bind()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_registration", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 2);

            cmd.Parameters.AddWithValue("@user_reg_id1",0);
            cmd.Parameters.AddWithValue("@user_name2", "");
            cmd.Parameters.AddWithValue("@first_name1", "");
            cmd.Parameters.AddWithValue("@last_name1", "");
            cmd.Parameters.AddWithValue("@pass1", "");
            cmd.Parameters.AddWithValue("@conformpass1", "");
            cmd.Parameters.AddWithValue("@email1", "");
            cmd.Parameters.AddWithValue("@gender1","");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "User Name";
            dataGridView1.Columns[2].HeaderText = "First Name";
            dataGridView1.Columns[3].HeaderText = "Last Name";
            dataGridView1.Columns[4].HeaderText = "Password";
            dataGridView1.Columns[5].HeaderText = "Conform Password";
            dataGridView1.Columns[6].HeaderText = "Email ";
            dataGridView1.Columns[7].HeaderText = "Gender";
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00B0B2");
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            dataGridView1.BackgroundColor = ColorTranslator.FromHtml("#cefeff");
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("ColumnHeadersDefaultCellStyle", 9F, FontStyle.Bold);
            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#6dfcfe");

            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            // Change back color of each row
            // dataGridView1.RowsDefaultCellStyle.BackColor = Color.AliceBlue;
            // Change GridLine Color
            // dataGridView1.GridColor = Color.Blue;
            // Change Grid Border Style
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.ReadOnly = true;
            }

            con.Close();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)  // ignore header row and any column
                return;   
            
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[index];
            resigration_id.Text = selectedRow.Cells[0].Value.ToString();
            user_name.Text = selectedRow.Cells[1].Value.ToString();
            first_name.Text = selectedRow.Cells[2].Value.ToString();
            last_name.Text= selectedRow.Cells[3].Value.ToString();
            password.Text= selectedRow.Cells[4].Value.ToString();
            conforpass.Text = selectedRow.Cells[5].Value.ToString();
            email.Text = selectedRow.Cells[6].Value.ToString();
            
            textBox1.Clear();
            button1.Text = "Update";
            button1.Enabled = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (user_name.Text == "" || first_name.Text == "" || last_name.Text == "" || password.Text == "" || conforpass.Text == "" || email.Text == "")
            {
                MessageBox.Show("field mandetory");
            }
            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_registration", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 3);
                cmd.Parameters.AddWithValue("@user_reg_id1", resigration_id.Text.ToString());
                cmd.Parameters.AddWithValue("@user_name2", user_name.Text.ToString());
                cmd.Parameters.AddWithValue("@first_name1", first_name.Text.ToString());
                cmd.Parameters.AddWithValue("@last_name1", last_name.Text.ToString());
                cmd.Parameters.AddWithValue("@pass1", password.Text.ToString());
                cmd.Parameters.AddWithValue("@conformpass1", conforpass.Text.ToString());
                cmd.Parameters.AddWithValue("@email1", email.Text.ToString());
                if (rdb_male.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@gender1", rdb_male.Text.ToString());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@gender1", rdb_female.Text.ToString());
                }

                if (password.Text != conforpass.Text)
                {
                    MessageBox.Show("confirm password not matching with new passsword");
                    conforpass.Focus();
                    return;

                }
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully registerd");
                grid_bind();
                ClearAllControl();
                con.Close();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


            if (textBox1.Text != "")
            {
                ClearAllControl();
                button1.Text = "Save";
                button1.Enabled = false;
                button4.Enabled = true;
            }
            else
            {
                button1.Text = "Save";
                button1.Enabled = true;
                button4.Enabled = true;

            }
            
            
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_registration", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 5);

            cmd.Parameters.AddWithValue("@user_reg_id1", 0);
            cmd.Parameters.AddWithValue("@user_name2", textBox1.Text.ToString());
            cmd.Parameters.AddWithValue("@first_name1", "");
            cmd.Parameters.AddWithValue("@last_name1", "");
            cmd.Parameters.AddWithValue("@pass1", "");
            cmd.Parameters.AddWithValue("@conformpass1", "");
            cmd.Parameters.AddWithValue("@email1", "");
            cmd.Parameters.AddWithValue("@gender1", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "User Name";
            dataGridView1.Columns[2].HeaderText = "First Name";
            dataGridView1.Columns[3].HeaderText = "Last Name";
            dataGridView1.Columns[4].HeaderText = "Password";
            dataGridView1.Columns[5].HeaderText = "conform Password";
            dataGridView1.Columns[6].HeaderText = "Email Address";

            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (user_name.Text == "" || first_name.Text == "" || last_name.Text == "" || password.Text == "" || conforpass.Text == "" || email.Text == "")
            {
                MessageBox.Show("field mandetory");
            }
            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_registration", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 4);
                cmd.Parameters.AddWithValue("@user_reg_id1", resigration_id.Text.ToString());
                cmd.Parameters.AddWithValue("@user_name2", "");
                cmd.Parameters.AddWithValue("@first_name1", "");
                cmd.Parameters.AddWithValue("@last_name1", "");
                cmd.Parameters.AddWithValue("@pass1", "");
                cmd.Parameters.AddWithValue("@conformpass1", "");
                cmd.Parameters.AddWithValue("@email1", "");
                if (rdb_male.Checked == true)
                {
                    cmd.Parameters.AddWithValue("@gender1", rdb_male.Text.ToString());
                }
                else
                {
                    cmd.Parameters.AddWithValue("@gender1", rdb_female.Text.ToString());
                }


                cmd.ExecuteNonQuery();
                MessageBox.Show("Delete Successfully ");
                grid_bind();
                ClearAllControl();
                con.Close();
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //this.Close();
            textBox1.Text = "";
            button1.Text = "Save";
            ClearAllControl();
            
        }

        private void ClearAllControl()
        {
            user_name.Clear();
            first_name.Clear();
            last_name.Clear();
            password.Clear();
            conforpass.Clear();
            email.Clear();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
             if (e.KeyCode == Keys.Enter)
            {

                int index = dataGridView1.CurrentRow.Index; ;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                resigration_id.Text = selectedRow.Cells[0].Value.ToString();
                user_name.Text = selectedRow.Cells[1].Value.ToString();
                first_name.Text = selectedRow.Cells[2].Value.ToString();
                last_name.Text = selectedRow.Cells[3].Value.ToString();
                password.Text = selectedRow.Cells[4].Value.ToString();
                conforpass.Text = selectedRow.Cells[5].Value.ToString();
                email.Text = selectedRow.Cells[6].Value.ToString();

                button1.Text = "Update";

            }

             if (e.KeyCode == Keys.Delete)
             {

                 var confirmResult = MessageBox.Show("Are you sure to delete this item ??",
                                      "Confirm Delete!!",
                                      MessageBoxButtons.YesNo);
                 if (confirmResult == DialogResult.Yes)
                 {

                     MySqlConnection con = new MySqlConnection(str1);
                     con.Open();
                     MySqlCommand cmd = new MySqlCommand("sp_registration", con);
                     cmd.CommandType = CommandType.StoredProcedure;
                     cmd.Parameters.AddWithValue("@flag", 4);
                     cmd.Parameters.AddWithValue("@user_reg_id1", resigration_id.Text.ToString());
                     cmd.Parameters.AddWithValue("@user_name2", "");
                     cmd.Parameters.AddWithValue("@first_name1", "");
                     cmd.Parameters.AddWithValue("@last_name1", "");
                     cmd.Parameters.AddWithValue("@pass1", "");
                     cmd.Parameters.AddWithValue("@conformpass1", "");
                     cmd.Parameters.AddWithValue("@email1", "");
                     if (rdb_male.Checked == true)
                     {
                         cmd.Parameters.AddWithValue("@gender1", rdb_male.Text.ToString());
                     }
                     else
                     {
                         cmd.Parameters.AddWithValue("@gender1", rdb_female.Text.ToString());
                     }


                     cmd.ExecuteNonQuery();
                     MessageBox.Show("Deleted Successfully ");
                     grid_bind();
                     ClearAllControl();
                     con.Close();


                 }
                 else
                 {
                     // If 'No', do something here.
                 }

             }
        }
    }
}
