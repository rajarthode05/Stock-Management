﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions; 

namespace Task1
{
    public partial class outward_entry : Form
    {
        string catno, makename, unitname;
        int new_stock, demo, previous_inward_stock, present_stock1, available_stock;
        string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;
        int present_stock, out_stock;
        public outward_entry()
        {
            InitializeComponent();
        }

        private void sum_quantity()
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum += int.Parse(dataGridView1.Rows[i].Cells[4].Value.ToString());
            }

            label13.Text = "Sum Quantity= " + sum.ToString();
            label13.Visible = true;
        }
        private void outward_entry_Load(object sender, EventArgs e)
        {
            grid_bind();
            Date.Text = DateTime.Now.ToString("dd/MM/yyyy");
            Time.Text = DateTime.Now.ToLongTimeString();
            sum_quantity();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsertintoStock();
        }

        private void outwardEntry()
        {
            if (product_description.Text == ""  || quantity.Text == "" || challan_No.Text == "" || site_name.Text == "")
            {
                MessageBox.Show("All Field are Mandatory...");
                return;
            }
            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 1);
                cmd.Parameters.AddWithValue("@outward_entry_id1", null);
                cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", product_description.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_ProductName1", product_name.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_catlogNo1", catlog_no.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Quantity1", quantity.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Unit1", units.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Date1", DateTime.Now.ToString("dd/MM/yyyy"));
                cmd.Parameters.AddWithValue("@out_ent_Time1", DateTime.Now.ToLongTimeString());
                cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", challan_No.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_SiteNo1", site_name.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Remark1", remark.Text.ToString());
                cmd.ExecuteNonQuery();
                MessageBox.Show("Outward Entry Saved Successfully");
                grid_bind();
                
                clearAllControl();
                con.Close();
            }
           
        }
        private void clearAllControl()
        {
            
            label12.Visible = false;
            product_description.Clear();
            quantity.Clear();
            product_name.Clear();
            catlog_no.Clear();
            units.Clear();
            Date.Clear();
            Time.Clear();
            challan_No.Clear();
            site_name.Clear();
            remark.Clear();
        }
        private void grid_bind()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 6);

            cmd.Parameters.AddWithValue("@outward_entry_id1", 0);
            cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", "");
            cmd.Parameters.AddWithValue("@out_ent_ProductName1","");
            cmd.Parameters.AddWithValue("@out_ent_catlogNo1","");
            cmd.Parameters.AddWithValue("@out_ent_Quantity1",  "");
            cmd.Parameters.AddWithValue("@out_ent_Unit1", "");
            cmd.Parameters.AddWithValue("@out_ent_Date1", DateTime.Now.ToString("dd/MM/yyyy"));
            cmd.Parameters.AddWithValue("@out_ent_Time1","");
            cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_SiteNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_Remark1", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Description";
            dataGridView1.Columns[2].HeaderText = "Make Name";
            dataGridView1.Columns[3].HeaderText = "Catlog No.";
            dataGridView1.Columns[4].HeaderText = "Quantity";
            dataGridView1.Columns[5].HeaderText = "Unit";
            dataGridView1.Columns[6].HeaderText = "Date";
            dataGridView1.Columns[7].HeaderText = "Time";
            dataGridView1.Columns[8].HeaderText = "Challan No.";
            dataGridView1.Columns[9].HeaderText = "Site Name";
            dataGridView1.Columns[10 ].HeaderText = "Remark";
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00B0B2");
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("ColumnHeadersDefaultCellStyle", 9F, FontStyle.Bold);
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.BackgroundColor = ColorTranslator.FromHtml("#cefeff");
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#6dfcfe");

            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            // Change back color of each row
            // dataGridView1.RowsDefaultCellStyle.BackColor = Color.AliceBlue;
            // Change GridLine Color
            // dataGridView1.GridColor = Color.Blue;
            // Change Grid Border Style
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.ReadOnly = true;
            }
           
            con.Close();

        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[index];
            outward_id.Text = selectedRow.Cells[0].Value.ToString();
            product_description.Text=selectedRow.Cells[1].Value.ToString();
         
            product_name.Text = selectedRow.Cells[2].Value.ToString();
            
            catlog_no.Text = selectedRow.Cells[3].Value.ToString();
            quantity.Text=selectedRow.Cells[4].Value.ToString();
            units.Text=selectedRow.Cells[5].Value.ToString();
            Date.Text=selectedRow.Cells[6].Value.ToString();
            Time.Text=selectedRow.Cells[7].Value.ToString();
            challan_No.Text=selectedRow.Cells[8].Value.ToString();
            site_name.Text=selectedRow.Cells[9].Value.ToString();
            remark.Text=selectedRow.Cells[10].Value.ToString();

            
            fetch_available_stock_when_cellclick();

            textBox6.Clear();
            button1.Text = "Update";
            button1.Enabled = true;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (product_description.Text == "" || quantity.Text == "" || units.Text == "" || challan_No.Text == "" || site_name.Text == "")
            {
                MessageBox.Show("Select Proper Field From List");
            }
            else
            {
                read_previous_quantity_before_update(); 
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 3);
                cmd.Parameters.AddWithValue("@outward_entry_id1", outward_id.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", product_description.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_ProductName1", product_name.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_catlogNo1", catlog_no.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Quantity1", quantity.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Unit1", units.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Date1", Date.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Time1", Time.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", challan_No.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_SiteNo1", site_name.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_Remark1", remark.Text.ToString());
                cmd.ExecuteNonQuery();
                MessageBox.Show("Outward Entry Save Successfully");
                grid_bind();
                updatestock_whenupdate_inward_entry();
                clearAllControl();
                sum_quantity();
                con.Close();
            }
            
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

            if (textBox6.Text != "")
            {
                clearAllControl();
                button1.Text = "Save";
                button1.Enabled = false;
                button2.Enabled = true;
            }
            else
            {

                button1.Text = "Save";
                button1.Enabled = true;
                button2.Enabled = true;


            }
            
            
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 5);

            cmd.Parameters.AddWithValue("@outward_entry_id1", 0);
            cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", textBox6.Text.ToString());
            cmd.Parameters.AddWithValue("@out_ent_ProductName1","");
            cmd.Parameters.AddWithValue("@out_ent_catlogNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_Quantity1", "");
            cmd.Parameters.AddWithValue("@out_ent_Unit1", "");
            cmd.Parameters.AddWithValue("@out_ent_Date1", "");
            cmd.Parameters.AddWithValue("@out_ent_Time1", "");
            cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_SiteNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_Remark1", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Description";
            dataGridView1.Columns[2].HeaderText = "Make Name";
            dataGridView1.Columns[3].HeaderText = "Catlog No.";
            dataGridView1.Columns[4].HeaderText = "Quantity";
            dataGridView1.Columns[5].HeaderText = "Unit";
            dataGridView1.Columns[6].HeaderText = "Date";
            dataGridView1.Columns[7].HeaderText = "Time";
            dataGridView1.Columns[8].HeaderText = "Challan No.";
            dataGridView1.Columns[9].HeaderText = "Site Name";
            dataGridView1.Columns[10].HeaderText = "Remark";
            con.Close();
            sum_quantity();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (product_description.Text == ""  || quantity.Text == "" || units.Text == "" || challan_No.Text == "" || site_name.Text == "")
            {
                MessageBox.Show("Select Proper Field From List");
            }
            else
            {
                read_stock_available();
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 4);
                cmd.Parameters.AddWithValue("@outward_entry_id1", outward_id.Text.ToString());
                cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", "");
                cmd.Parameters.AddWithValue("@out_ent_ProductName1", "");
                cmd.Parameters.AddWithValue("@out_ent_catlogNo1", "");
                cmd.Parameters.AddWithValue("@out_ent_Quantity1", "");
                cmd.Parameters.AddWithValue("@out_ent_Unit1", "");
                cmd.Parameters.AddWithValue("@out_ent_Date1", "");
                cmd.Parameters.AddWithValue("@out_ent_Time1", "");
                cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", "");
                cmd.Parameters.AddWithValue("@out_ent_SiteNo1", "");
                cmd.Parameters.AddWithValue("@out_ent_Remark1", "");
                cmd.ExecuteNonQuery();
                delete_from_stock();
                MessageBox.Show("Delete Successfully");
                grid_bind();
                clearAllControl();
                sum_quantity();
                con.Close();
            }
           
        }

        private void delete_from_stock()
        {

            available_stock = available_stock + Convert.ToInt32(quantity.Text.ToString());
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 3);
            cmd.Parameters.AddWithValue("@stock_id1", null);

            cmd.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_product_name1",product_name.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_catlogNo1",catlog_no.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_quantity1", Convert.ToString(available_stock).ToString());
            cmd.Parameters.AddWithValue("@stock_units1", "");


            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void read_stock_available()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd1 = new MySqlCommand("sp_stock", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.AddWithValue("@flag", 12);
            cmd1.Parameters.AddWithValue("@stock_id1", 0);
            cmd1.Parameters.AddWithValue("@stock_product_description1",product_description.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_product_name1", product_name.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_quantity1", "");
            cmd1.Parameters.AddWithValue("@stock_units1", "");

            MySqlDataReader dr = cmd1.ExecuteReader();

            if (dr.Read())
            {
                available_stock = Convert.ToInt32(dr[4].ToString());
            }
            dr.Close();

        }
        private void button2_Click(object sender, EventArgs e)
        {
            //this.Close();
            clearAllControl();
            button1.Text = "Save";
        }

        private void InsertintoStock()
        {

            try
            {
                //if (!Regex.IsMatch(product_description.Text.ToString().Trim(), @"^[a-zA-Z0-9\s]+$"))
                //{
                //    MessageBox.Show("Please Enter Proper Description.");
                //    product_description.Focus();

                //}

                if (!Regex.IsMatch(quantity.Text.ToString().Trim(), @"^[0-9]+$"))
                {
                    MessageBox.Show("Please Enter Proper Quantity.");
                    quantity.Focus();

                }

                if (!Regex.IsMatch(site_name.Text.ToString().Trim(), @"^[a-zA-Z\s]+$"))
                {
                    MessageBox.Show("Please Enter Proper Site Name.");
                    quantity.Focus();

                }

                else
                {
                    MySqlConnection con = new MySqlConnection(str1);
                    con.Open();
                    MySqlCommand cmd1 = new MySqlCommand("sp_stock", con);
                    cmd1.CommandType = CommandType.StoredProcedure;

                    if (button1.Text == "Save")
                    {
                        cmd1.Parameters.AddWithValue("@id", 1);
                        cmd1.Parameters.AddWithValue("@sp_inward_sr_no", 0);
                        cmd1.Parameters.AddWithValue("@flag", 4);
                        cmd1.Parameters.AddWithValue("@stock_id1", null);
                        cmd1.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
                        cmd1.Parameters.AddWithValue("@stock_product_name1", product_name.Text.ToString());
                        cmd1.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
                        cmd1.Parameters.AddWithValue("@stock_quantity1", quantity.Text.ToString());
                        cmd1.Parameters.AddWithValue("@stock_units1", units.Text.ToString());

                        MySqlDataReader dr = cmd1.ExecuteReader();
                        if (dr.Read())
                        {
                            present_stock = Convert.ToInt32(dr[4].ToString());

                            out_stock = present_stock - Convert.ToInt32(quantity.Text.ToString());

                            present_stock1= Convert.ToInt32(quantity.Text.ToString());
                            if (present_stock1==0)
                            {
                                MessageBox.Show("Enter proper quantity" );
                            }
                            else if (present_stock < present_stock1)
                            {
                                MessageBox.Show("Insufficient stock...!" + "Your Available Stock is:" + present_stock);
                            }
                            else
                            {
                                dr.Close();

                                MySqlCommand cmd = new MySqlCommand("sp_stock", con);
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.AddWithValue("@flag", 3);
                                cmd.Parameters.AddWithValue("@stock_id1", null);

                                cmd.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
                                cmd.Parameters.AddWithValue("@stock_product_name1", product_name.Text.ToString());
                                cmd.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
                                cmd.Parameters.AddWithValue("@stock_quantity1", Convert.ToString(out_stock).ToString());
                                cmd.Parameters.AddWithValue("@stock_units1", units.Text.ToString());
                                cmd.ExecuteNonQuery();
                                outwardEntry();

                            }

                        }
                        else
                        {
                            dr.Close();

                            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@flag", 1);
                            cmd.Parameters.AddWithValue("@stock_id1", null);
                            cmd.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
                            cmd.Parameters.AddWithValue("@stock_product_name1", product_name.Text.ToString());
                            cmd.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
                            cmd.Parameters.AddWithValue("@stock_quantity1", quantity.Text.ToString());
                            cmd.Parameters.AddWithValue("@stock_units1", units.Text.ToString());
                            cmd.ExecuteNonQuery();

                        }
                        sum_quantity();

                    }


                    if (button1.Text == "Update")
                    {

                        read_previous_quantity_before_update();
                       // MySqlConnection con = new MySqlConnection(str1);
                        if (con != null && con.State == ConnectionState.Closed)
                        {
                            con.Open();
                        } 
                        MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@flag", 3);
                        cmd.Parameters.AddWithValue("@outward_entry_id1", outward_id.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", product_description.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_ProductName1", product_name.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_catlogNo1", catlog_no.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_Quantity1", quantity.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_Unit1", units.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_Date1", Date.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_Time1", Time.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", challan_No.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_SiteNo1", site_name.Text.ToString());
                        cmd.Parameters.AddWithValue("@out_ent_Remark1", remark.Text.ToString());
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Outward Entry Saved Successfully");
                        grid_bind();
                        updatestock_whenupdate_inward_entry();
                        clearAllControl();
                        sum_quantity();
                        con.Close();

                        button1.Text = "Save";

                    }

                    con.Close();
                }
                    
                 
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        
        }
        
        private void product_description_TextChanged(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_stock ", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 8);
                cmd.Parameters.AddWithValue("@stock_id1", null);
                cmd.Parameters.AddWithValue("@stock_product_description1",product_description.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_product_name1", "");
                cmd.Parameters.AddWithValue("@stock_catlogNo1", "");
                cmd.Parameters.AddWithValue("@stock_quantity1", "");
                cmd.Parameters.AddWithValue("@stock_units1", "");
                cmd.ExecuteNonQuery();
                MySqlDataAdapter da = new MySqlDataAdapter();
            
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                AutoCompleteStringCollection col = new AutoCompleteStringCollection();
                while (dr.Read())
                {
                    col.Add(dr["stock_product_description"].ToString());
                }
                product_description.AutoCompleteCustomSource = col;
                
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void product_description_Leave(object sender, EventArgs e)
        {
            try
            {
                if(product_description.Text.ToString()=="")
                {

                }
                else
                {
                    MySqlConnection con = new MySqlConnection(str1);
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("sp_stock ", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@flag", 9);
                    cmd.Parameters.AddWithValue("@stock_id1", null);
                    cmd.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
                    cmd.Parameters.AddWithValue("@stock_product_name1", "");
                    cmd.Parameters.AddWithValue("@stock_catlogNo1", "");
                    cmd.Parameters.AddWithValue("@stock_quantity1", "");
                    cmd.Parameters.AddWithValue("@stock_units1", "");
                    cmd.ExecuteNonQuery();
                    MySqlDataAdapter da = new MySqlDataAdapter();

                    MySqlDataReader dr;
                    dr = cmd.ExecuteReader();

                    if (dr.Read())
                    {
                        product_name.Text = dr[2].ToString();
                        catlog_no.Text = dr[3].ToString();
                        units.Text = dr[5].ToString();
                        label12.Text = "Available Quantity= " + dr[4].ToString();
                        label12.Visible = true;

                    }

               
                }
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

      
        private void fetch_available_stock_when_cellclick()
        {
            try
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_stock ", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 4);
                cmd.Parameters.AddWithValue("@stock_id1", null);
                cmd.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_product_name1",product_name.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_quantity1", "");
                cmd.Parameters.AddWithValue("@stock_units1",units.Text.ToString());
                cmd.ExecuteNonQuery();
                MySqlDataAdapter da = new MySqlDataAdapter();

                MySqlDataReader dr;
                dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    
                    label12.Text = "Available Quantity= " + dr[4].ToString();
                    label12.Visible = true;

                }



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
       
        private void units_TextChanged(object sender, EventArgs e)
        {
            try
            {
                MySqlConnection con = new MySqlConnection(str1);
                MySqlCommand cmd = new MySqlCommand("sp_stock_unit", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 6);
                cmd.Parameters.AddWithValue("@stock_unit_id1", null);
                cmd.Parameters.AddWithValue("@unit_name1", units.Text.ToString());
                MySqlDataAdapter da = new MySqlDataAdapter();
                con.Open();
                MySqlDataReader dr;

                cmd.ExecuteNonQuery();
                dr = cmd.ExecuteReader();
                AutoCompleteStringCollection col = new AutoCompleteStringCollection();
                while (dr.Read())
                {
                    col.Add(dr["unit_name"].ToString());
                }
                units.AutoCompleteCustomSource = col;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void read_previous_quantity_before_update()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 7);
            cmd.Parameters.AddWithValue("@outward_entry_id1", outward_id.Text.ToString());
            cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", "");
            cmd.Parameters.AddWithValue("@out_ent_ProductName1", "");
            cmd.Parameters.AddWithValue("@out_ent_catlogNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_Quantity1", "");
            cmd.Parameters.AddWithValue("@out_ent_Unit1", "");
            cmd.Parameters.AddWithValue("@out_ent_Date1", "");
            cmd.Parameters.AddWithValue("@out_ent_Time1", "");
            cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_SiteNo1", "");
            cmd.Parameters.AddWithValue("@out_ent_Remark1", "");
            
            MySqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                store_previous_quantity.Text = dr[4].ToString();
                makename = dr[2].ToString();
                catno = dr[3].ToString();
                unitname = dr[5].ToString();

            }


        }

        private void updatestock_whenupdate_inward_entry()
        {
            try
            {

                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd1 = new MySqlCommand("sp_stock", con);
                cmd1.CommandType = CommandType.StoredProcedure;
                cmd1.Parameters.AddWithValue("@flag", 12);

                cmd1.Parameters.AddWithValue("@stock_id1", null);
                cmd1.Parameters.AddWithValue("@stock_product_description1",product_description.Text.ToString());
                cmd1.Parameters.AddWithValue("@stock_product_name1",product_name.Text.ToString());
                cmd1.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
                cmd1.Parameters.AddWithValue("@stock_quantity1", quantity.Text.ToString());
                cmd1.Parameters.AddWithValue("@stock_units1",units.Text.ToString());

                MySqlDataReader dr = cmd1.ExecuteReader();
                if (dr.Read())
                {
                    present_stock = Convert.ToInt32(dr[4].ToString());
                    new_stock = Convert.ToInt32(quantity.Text.ToString());
                    previous_inward_stock = Convert.ToInt32(store_previous_quantity.Text.ToString());

                    if (new_stock > previous_inward_stock)
                    {
                        demo = new_stock - previous_inward_stock;
                        present_stock = present_stock- demo;

                    }
                    else
                    {
                        demo = previous_inward_stock - new_stock;
                        present_stock = present_stock + demo;
                    }
                    dr.Close();
                    MySqlCommand cmd = new MySqlCommand("sp_stock", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@flag", 3);
                    cmd.Parameters.AddWithValue("@stock_id1", null);

                    cmd.Parameters.AddWithValue("@stock_product_description1", product_description.Text.ToString());
                    cmd.Parameters.AddWithValue("@stock_product_name1",product_name.Text.ToString());
                    cmd.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
                    cmd.Parameters.AddWithValue("@stock_quantity1", Convert.ToString(present_stock).ToString());
                    cmd.Parameters.AddWithValue("@stock_units1","");
                    cmd.ExecuteNonQuery();

                }


                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void quantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                int index = dataGridView1.CurrentRow.Index;

                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                outward_id.Text = selectedRow.Cells[0].Value.ToString();
                product_description.Text = selectedRow.Cells[1].Value.ToString();
                product_name.Text = selectedRow.Cells[2].Value.ToString();
                catlog_no.Text = selectedRow.Cells[3].Value.ToString();
                quantity.Text = selectedRow.Cells[4].Value.ToString();
                units.Text = selectedRow.Cells[5].Value.ToString();
                Date.Text = selectedRow.Cells[6].Value.ToString();
                Time.Text = selectedRow.Cells[7].Value.ToString();
                challan_No.Text = selectedRow.Cells[8].Value.ToString();
                site_name.Text = selectedRow.Cells[9].Value.ToString();
                remark.Text = selectedRow.Cells[10].Value.ToString();
                textBox6.Clear();
                button1.Text = "Update";
                button1.Enabled = true;
            }
            if (e.KeyCode == Keys.Delete)
            {
                var confirmResult = MessageBox.Show("Are you sure to delete this item ??",
                                    "Confirm Delete!!",
                                    MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {

                    if (outward_id.Text.ToString() == "")
                    {
                        MessageBox.Show("Select Proper Entry");
                        return;
                    }
                   
                    read_stock_available();
                    MySqlConnection con = new MySqlConnection(str1);
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("sp_outward_entry", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@flag", 4);
                    cmd.Parameters.AddWithValue("@outward_entry_id1", outward_id.Text.ToString());
                    cmd.Parameters.AddWithValue("@out_ent_ProductDesription1", "");
                    cmd.Parameters.AddWithValue("@out_ent_ProductName1", "");
                    cmd.Parameters.AddWithValue("@out_ent_catlogNo1", "");
                    cmd.Parameters.AddWithValue("@out_ent_Quantity1", "");
                    cmd.Parameters.AddWithValue("@out_ent_Unit1", "");
                    cmd.Parameters.AddWithValue("@out_ent_Date1", "");
                    cmd.Parameters.AddWithValue("@out_ent_Time1", "");
                    cmd.Parameters.AddWithValue("@out_ent_ChallanNo1", "");
                    cmd.Parameters.AddWithValue("@out_ent_SiteNo1", "");
                    cmd.Parameters.AddWithValue("@out_ent_Remark1", "");
                    cmd.ExecuteNonQuery();
                    delete_from_stock();
                    MessageBox.Show("Delete Successfully");
                    grid_bind();
                    clearAllControl();
                    con.Close();
                    button1.Text = "Save";
                }
                   
            }
            else
            {

            }


        }

        private void button5_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }
            }
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveDialog.FilterIndex = 2;

            if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                workbook.SaveAs(saveDialog.FileName);
                MessageBox.Show("Saved Successfully");
            }                

        }

    }
}
