﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
namespace Task1
{
    public partial class Stock : Form
    {
         string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;
        public Stock()
        {
            InitializeComponent();
        }

        private void sum_quantity()
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum += int.Parse(dataGridView1.Rows[i].Cells[4].Value.ToString());
            }

            label4.Text = "Sum Quantity= " + sum.ToString();
            label4.Visible = true;
        }
        private void cancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Stock_Load(object sender, EventArgs e)
        {
            grid_bind();
            sum_quantity();
        }
        private void grid_bind()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@flag", 2);
            cmd.Parameters.AddWithValue("@stock_id1",null);
            cmd.Parameters.AddWithValue("@stock_product_description1", "");
            cmd.Parameters.AddWithValue("@stock_product_name1", "");
            cmd.Parameters.AddWithValue("@stock_catlogNo1", "");
            cmd.Parameters.AddWithValue("@stock_quantity1","");
            cmd.Parameters.AddWithValue("@stock_units1", "");

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Product Description";
            dataGridView1.Columns[2].HeaderText = "Make Name";
            dataGridView1.Columns[3].HeaderText = "Catlog No.";
            dataGridView1.Columns[4].HeaderText = "Quantity Available";
            dataGridView1.Columns[5].HeaderText = "Units";
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00B0B2");
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("ColumnHeadersDefaultCellStyle", 9F, FontStyle.Bold);

            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.BackgroundColor = ColorTranslator.FromHtml("#cefeff");
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#6dfcfe");

            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            // Change back color of each row
            // dataGridView1.RowsDefaultCellStyle.BackColor = Color.AliceBlue;
            // Change GridLine Color
            // dataGridView1.GridColor = Color.Blue;
            // Change Grid Border Style
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.ReadOnly = true;
            }
            con.Close();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            description.Clear();
            manufact_name.Clear();
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@flag", 5);
            cmd.Parameters.AddWithValue("@stock_id1", null);
            cmd.Parameters.AddWithValue("@stock_product_description1", "");
            cmd.Parameters.AddWithValue("@stock_product_name1", "");
            cmd.Parameters.AddWithValue("@stock_catlogNo1", catlog_no.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_quantity1","");
            cmd.Parameters.AddWithValue("@stock_units1", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Product Description";
            dataGridView1.Columns[2].HeaderText = "Make Name";
            dataGridView1.Columns[3].HeaderText = "Catlog No.";
            dataGridView1.Columns[4].HeaderText = "Quantity Available";
            dataGridView1.Columns[5].HeaderText = "Units";
            con.Close();
            sum_quantity();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            catlog_no.Clear();
            description.Clear();
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@flag", 6);
            cmd.Parameters.AddWithValue("@stock_id1", null);
            cmd.Parameters.AddWithValue("@stock_product_description1", "");
            cmd.Parameters.AddWithValue("@stock_product_name1",manufact_name.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_catlogNo1", "");
            cmd.Parameters.AddWithValue("@stock_quantity1", "");
            cmd.Parameters.AddWithValue("@stock_units1", "");

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Product Description";
            dataGridView1.Columns[2].HeaderText = "Make Name";
            dataGridView1.Columns[3].HeaderText = "Catlog No.";
            dataGridView1.Columns[4].HeaderText = "Quantity Available";
            dataGridView1.Columns[5].HeaderText = "Units";
            con.Close();
            sum_quantity();
        }

        private void description_TextChanged(object sender, EventArgs e)
        {
            catlog_no.Clear();
            manufact_name.Clear();
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@flag", 7);
            cmd.Parameters.AddWithValue("@stock_id1", null);
            cmd.Parameters.AddWithValue("@stock_product_description1", description.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_product_name1", "");
            cmd.Parameters.AddWithValue("@stock_catlogNo1", "");
            cmd.Parameters.AddWithValue("@stock_quantity1", "");
            cmd.Parameters.AddWithValue("@stock_units1", "");

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Product Description";
            dataGridView1.Columns[2].HeaderText = "Make Name";
            dataGridView1.Columns[3].HeaderText = "Catlog No.";
            dataGridView1.Columns[4].HeaderText = "Quantity Available";
            dataGridView1.Columns[5].HeaderText = "Units";
            con.Close();
            sum_quantity();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            // creating new WorkBook within Excel application  
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            // creating new Excelsheet in workbook  
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            // see the excel sheet behind the program  
            app.Visible = true;
            // get the reference of first sheet. By default its name is Sheet1.  
            // store its reference to worksheet  
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            // changing the name of active sheet  
            worksheet.Name = "Exported from gridview";
            // storing header part in Excel  
            for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
            {
                worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }
            // storing Each row and column value to excel sheet  
            for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }
            }
            // save the application  
            //workbook.SaveAs("D:\\Stock.xls", Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            // Exit from the application 
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveDialog.FilterIndex = 2;

            if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                workbook.SaveAs(saveDialog.FileName);
                MessageBox.Show("Saved Successfully");
            }                

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        
    }
}
