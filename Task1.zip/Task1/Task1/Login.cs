﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace Task1
{
    public partial class Login : Form
    {
        string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            //groupBox1.BackColor = Color.Transparent;
            //textBox1.BackColor = Color.Transparent;
            //textBox2.BackColor = Color.Transparent;

            button1.TabStop = false;
            button1.FlatStyle = FlatStyle.Flat;
            button1.FlatAppearance.BorderSize = 0;
            textBox1.BorderStyle = 0;
            textBox2.BorderStyle = 0;

            textBox2.GotFocus += new System.EventHandler(this.textBox2_GotFocus);
          

        }

        private void textBox1_GotFocus(Object sender, EventArgs e)
        {
            textBox1.Text = "";
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("field mandetory");
            }
            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd1 = new MySqlCommand("Select * from user_registration where  user_name1='" + textBox1.Text.ToString().Trim() + "' and  pass='" + textBox2.Text.ToString().Trim() + "'", con);
                int c = 0;
                MySqlDataReader dr = cmd1.ExecuteReader();
                while (dr.Read())
                {
                    if (dr.HasRows == true)
                    {
                        c = 1;

                        Home obj = new Home();
                        obj.Show();
                        this.Hide();
                        
                        break;
                    }

                }
                if(c==0)
                {
                    MessageBox.Show("Check Username And Password");
                }
                con.Close();

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Registration obj = new Registration();
            obj.Show();
        }

       
       

       

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "UserName")
                            textBox1.Text = "";

            if (textBox2.Text == "")
            {
                textBox2.Text = "Password";
                textBox2.PasswordChar = '\0';
            }
         //   textBox1.GotFocus += new System.EventHandler(this.textBox1_GotFocus);
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "Password")
                        textBox2.Text = "";
                   textBox2.PasswordChar = '*';

            if (textBox1.Text == "")
                textBox1.Text = "UserName";

        }

        private void textBox2_GotFocus(Object sender, EventArgs e)
        {
            if (textBox2.Text == "Password")
                textBox2.Text = "";
            textBox2.PasswordChar = '*';
        }

    }
}
