﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Text.RegularExpressions;
using System.IO;

namespace Task1
{
    public partial class Form1 : Form
    {
        string catno  , makename , unitname ;

        string cmb_unit_name = "";
        string cmb_make_name = "";
        int inward_update_val1,outward_val1;
        int present_stock,new_stock,demo,previous_inward_stock,available_stock;
        string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;


        public Form1()
        {
            InitializeComponent();
            Fillcombo();
            Fillcombo1();
        }

        private void sum_quantity()
        {
            int sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                sum += int.Parse(dataGridView1.Rows[i].Cells[6].Value.ToString());
            }

            label8.Text = "Sum Quantity= " + sum.ToString();
            label8.Visible = true;
        }
        public void Fillcombo()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock_unit  ", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 2);

            cmd.Parameters.AddWithValue("@stock_unit_id1", 0);
            cmd.Parameters.AddWithValue("@unit_name1", "");

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            DataRow row = dt.NewRow();
            row[0] = 0;
            row[1] = "";
            dt.Rows.InsertAt(row, 0);

            //Assign DataTable as DataSource.

            unit_combo.DataSource = dt;
            unit_combo.DisplayMember = "unit_name";
            unit_combo.ValueMember = "stock_unit_id";

            //Set AutoCompleteMode.
            unit_combo.AutoCompleteMode = AutoCompleteMode.Suggest;
            unit_combo.AutoCompleteSource = AutoCompleteSource.ListItems;

            con.Close();



        }

        public void Fillcombo1()
        {
          

            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 2);

            cmd.Parameters.AddWithValue("@stock_menufacture_id1", 0);
            cmd.Parameters.AddWithValue("@menu_name1", "");

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);

            DataRow row = dt.NewRow();
            row[0] = 0;
            row[1] = "";
            dt.Rows.InsertAt(row, 0);

            //Assign DataTable as DataSource.

            make_combo.DataSource = dt;
            make_combo.DisplayMember = "menu_name";
            make_combo.ValueMember = "stock_menufacture_id";

            //Set AutoCompleteMode.
            make_combo.AutoCompleteMode = AutoCompleteMode.Suggest;
            make_combo.AutoCompleteSource = AutoCompleteSource.ListItems;

            con.Close();
        }
        private void submit_Click(object sender, EventArgs e)
        {

            try
            {
            //    if (!Regex.IsMatch(description.Text.ToString().Trim(), @"^[a-zA-Z0-9\s]+$"))
            //    {
            //        MessageBox.Show("Please Enter Proper Description.");
            //        description.Focus();

            //    }

            //    if (!Regex.IsMatch(cat_no.Text.ToString().Trim(), @"^[a-zA-Z0-9]+$"))
            //    {
            //        MessageBox.Show("Please Enter Proper CAT NO.");
            //        cat_no.Focus();

            //    }

                if (!Regex.IsMatch(opening_qty.Text.ToString().Trim(), @"^[0-9]+$"))
                {
                    MessageBox.Show("Please Enter Proper Opening Qty.");
                    opening_qty.Focus();
                    return;

                }

                if (make_combo.SelectedIndex == -1)
                {
                    MessageBox.Show("Please Select Proper Make Name");
                    make_combo.Focus();
                    return;
                }

                if (unit_combo.SelectedIndex == -1)
                {
                    MessageBox.Show("Please Select Proper Unit Name");
                    unit_combo.Focus();
                    return;
                }


                else
                {

                    if (save.Text == "Save")
                    {
                        MySqlConnection con = new MySqlConnection(str1);
                        con.Open();
                        MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@id", 1);
                        cmd.Parameters.AddWithValue("@sp_inward_sr_no", 0);
                        cmd.Parameters.AddWithValue("@inw_ent_date", date_tb.Text.ToString());
                        cmd.Parameters.AddWithValue("@inw_ent_time", time_tb.Text.ToString());
                        cmd.Parameters.AddWithValue("@sp_inw_ent_description", description.Text.ToString());
                        cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", cat_no.Text.ToString());
                        cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", make_combo.Text.ToString());
                        cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", opening_qty.Text.ToString());
                        cmd.Parameters.AddWithValue("@sp_inw_ent_unit", unit_combo.Text.ToString());
                        cmd.Parameters.AddWithValue("@sp_inw_remark", remark.Text.ToString());
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Saved Successfully.....");
                        save.Text = "Save";
                        grid_bind();
                        con.Close();
                        InsertintoStock();
                        clearAllControl();
                        sum_quantity(); ;

                    }
                    if (save.Text == "Update")
                    {
                        read_outvard_entry();
                        if (label9.Text.ToString()!= "")
                        {
                            inward_update_val1 = Convert.ToInt32(opening_qty.Text.ToString());
                            outward_val1 = Convert.ToInt32(label9.Text.ToString());
                        }
                        else
                        {
                            inward_update_val1 = Convert.ToInt32(opening_qty.Text.ToString());
                            outward_val1 = 0;
                        }
                       
                if (inward_update_val1 < outward_val1)
                {

                    MessageBox.Show("Already" + outward_val1 + " outward Entry goes.You can't update it ");

                }
                else
                {
                    read_previous_quantity_before_update();
                    MySqlConnection con = new MySqlConnection(str1);
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", 3);
                    cmd.Parameters.AddWithValue("@sp_inward_sr_no", Convert.ToInt32(lbl_id.Text.ToString()));
                    cmd.Parameters.AddWithValue("@inw_ent_date", date_tb.Text.ToString());
                    cmd.Parameters.AddWithValue("@inw_ent_time", time_tb.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_description", description.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", cat_no.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", make_combo.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", opening_qty.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_unit", unit_combo.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_remark", remark.Text.ToString());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated Successfully.....");
                    grid_bind();
                    updatestock_whenupdate_inward_entry();
                    con.Close();
                    clearAllControl();
                    opening_qty.Text = " ";
                    sum_quantity();
                    save.Text = "Save";
                    save.Enabled = true;
                }
                    }


                }
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

            date_tb.Text = DateTime.Now.ToString("dd/MM/yyyy");
            time_tb.Text = DateTime.Now.ToLongTimeString();
            
            grid_bind();
            save.Text = "Save";
            sum_quantity();

         //   unit_combo.SelectedIndex = -1;
          //  make_combo.SelectedIndex = -1;

        }

        private void delete_Click(object sender, EventArgs e)
        {
            //this.Close();

            save.Text = "Save";
            
            textBox1.Text = "";
            clearAllControl();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            if (textBox1.Text != "")
            {
                clearAllControl();
                button1.Text = "Save";
                save.Enabled = false;
                cancel.Enabled = true;
            }
            else
            {
                save.Text = "Save";
                save.Enabled = true;
                cancel.Enabled = true;

            }
            
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", 5);
            cmd.Parameters.AddWithValue("@sp_inward_sr_no", 0);
            cmd.Parameters.AddWithValue("@inw_ent_date", "");
            cmd.Parameters.AddWithValue("@inw_ent_time", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_description",textBox1.Text.ToString());
            cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", 0);
            cmd.Parameters.AddWithValue("@sp_inw_ent_unit", "");
            cmd.Parameters.AddWithValue("@sp_inw_remark", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Date";
            dataGridView1.Columns[2].HeaderText = "Time";
            dataGridView1.Columns[3].HeaderText = "Description";
            dataGridView1.Columns[4].HeaderText = "CAT.NO.";
            dataGridView1.Columns[5].HeaderText = "Make Name";
            dataGridView1.Columns[6].HeaderText = "Opening Qty.";
            dataGridView1.Columns[7].HeaderText = "Unit";
            dataGridView1.Columns[8].HeaderText = "Remark";
            con.Close();
            sum_quantity();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void grid_bind()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", 2);
            cmd.Parameters.AddWithValue("@sp_inward_sr_no", 0);
            cmd.Parameters.AddWithValue("@inw_ent_date","");
            cmd.Parameters.AddWithValue("@inw_ent_time","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_description","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_product_name","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty",0);
            cmd.Parameters.AddWithValue("@sp_inw_ent_unit","");
            cmd.Parameters.AddWithValue("@sp_inw_remark", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Date";
            dataGridView1.Columns[2].HeaderText = "Time";
            dataGridView1.Columns[3].HeaderText = "Description";
            dataGridView1.Columns[4].HeaderText = "CAT.NO.";
            dataGridView1.Columns[5].HeaderText = "Manufacture Name";
            dataGridView1.Columns[6].HeaderText = "Qty";
            dataGridView1.Columns[7].HeaderText = "Unit";
            dataGridView1.Columns[8].HeaderText = "Remark";
         
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00B0B2");

            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("ColumnHeadersDefaultCellStyle", 9F, FontStyle.Bold);

            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.BackgroundColor = ColorTranslator.FromHtml("#cefeff");
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#6dfcfe");

            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            // Change back color of each row
            // dataGridView1.RowsDefaultCellStyle.BackColor = Color.AliceBlue;
            // Change GridLine Color
            // dataGridView1.GridColor = Color.Blue;
            // Change Grid Border Style
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.ReadOnly = true;
            }
            con.Close();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //BindingSource bs = new BindingSource();
            //bs.DataSource = dataGridView1.DataSource;
            //bs.Filter = dataGridView1.Columns[3].HeaderText.ToString() + " LIKE '%" + textBox1.Text + "%'";
            //dataGridView1.DataSource = bs; 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (description.Text == "" || cat_no.Text == "" || make_combo.Text == "" || opening_qty.Text == "" ||unit_combo.Text=="")
            {
                MessageBox.Show("Select proper field from list");
            }
            else
            {

                read_outvard_entry();
             
                if (label9.Text.ToString() != "")
                {
                    inward_update_val1 = Convert.ToInt32(opening_qty.Text.ToString());
                    outward_val1 = Convert.ToInt32(label9.Text.ToString());
                }
                else
                {
                    inward_update_val1 = Convert.ToInt32(opening_qty.Text.ToString());
                    outward_val1 = 0;
                }
                if (inward_update_val1 < outward_val1)
                {

                    MessageBox.Show("Already"+ outward_val1+" outward Entry goes.You can't update it " );

                }
                else
                {
                    read_previous_quantity_before_update();
                    MySqlConnection con = new MySqlConnection(str1);
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", 3);
                    cmd.Parameters.AddWithValue("@sp_inward_sr_no", Convert.ToInt32(lbl_id.Text.ToString()));
                    cmd.Parameters.AddWithValue("@inw_ent_date", date_tb.Text.ToString());
                    cmd.Parameters.AddWithValue("@inw_ent_time", time_tb.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_description", description.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", cat_no.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", make_combo.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", opening_qty.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_unit", unit_combo.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_remark", remark.Text.ToString());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated Successfully.....");
                    grid_bind();
                    updatestock_whenupdate_inward_entry();
                    con.Close();
                    clearAllControl();
                    opening_qty.Text = " ";
                    sum_quantity();
                    save.Text = "Save";
                    save.Enabled = true;
                    
                }
               

            }
            
        }

 
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
            
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[index];
            lbl_id.Text = selectedRow.Cells[0].Value.ToString();
            date_tb.Text = selectedRow.Cells[1].Value.ToString();
            time_tb.Text = selectedRow.Cells[2].Value.ToString();
            description.Text = selectedRow.Cells[3].Value.ToString();
            cat_no.Text = selectedRow.Cells[4].Value.ToString();
            make_combo.Text = selectedRow.Cells[5].Value.ToString();
            opening_qty.Text = selectedRow.Cells[6].Value.ToString();
            unit_combo.Text = selectedRow.Cells[7].Value.ToString();
            remark.Text = selectedRow.Cells[8].Value.ToString();
            description.ReadOnly = true;
            make_combo.Enabled = false;
            cat_no.ReadOnly = true;
            textBox1.Clear();
            save.Text = "Update";
            save.Enabled= true;
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (description.Text == "" || cat_no.Text == "" || make_combo.Text=="" || opening_qty.Text == "" || unit_combo.Text=="")
            {
                MessageBox.Show("Select proper field from list");
            }
            else
            {              
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();               
                
                new_stock = Convert.ToInt32(opening_qty.Text.ToString());
                read_stock_available();
                if(available_stock<new_stock)
                {
                    MessageBox.Show("Already outward Entry goes.You can't delete it");
                }
                else
                {
                    MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@id", 4);
                    cmd.Parameters.AddWithValue("@sp_inward_sr_no", Convert.ToInt32(lbl_id.Text.ToString()));
                    cmd.Parameters.AddWithValue("@inw_ent_date", date_tb.Text.ToString());
                    cmd.Parameters.AddWithValue("@inw_ent_time", time_tb.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_description", description.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", cat_no.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", make_combo.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", opening_qty.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_ent_unit", unit_combo.Text.ToString());
                    cmd.Parameters.AddWithValue("@sp_inw_remark", remark.Text.ToString());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully.....");
                    delete_from_stock();
                    sum_quantity();

                }
                
               
                grid_bind();
                con.Close();
                clearAllControl();
            }
            
        }

        private void search_bind()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", 5);
            cmd.Parameters.AddWithValue("@sp_inward_sr_no", Convert.ToInt32(lbl_id.Text.ToString()));
            cmd.Parameters.AddWithValue("@inw_ent_date", "");
            cmd.Parameters.AddWithValue("@inw_ent_time", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_description", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", 0);
            cmd.Parameters.AddWithValue("@sp_inw_ent_unit", "");
            cmd.Parameters.AddWithValue("@sp_inw_remark", "");
            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void InsertintoStock()
        {

            try
            { 

            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd1 = new MySqlCommand("sp_stock", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.AddWithValue("@flag", 4);

            cmd1.Parameters.AddWithValue("@stock_id1", null);
            cmd1.Parameters.AddWithValue("@stock_product_description1", description.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_product_name1", make_combo.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_quantity1", opening_qty.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_units1",unit_combo.Text.ToString());
                
            MySqlDataReader dr = cmd1.ExecuteReader();
            if (dr.Read())             
            {
                present_stock = Convert.ToInt32(dr[4].ToString());            
                new_stock = present_stock + Convert.ToInt32(opening_qty.Text.ToString());
                dr.Close();
                MySqlCommand cmd = new MySqlCommand("sp_stock", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 3);
                cmd.Parameters.AddWithValue("@stock_id1", null);
               
                cmd.Parameters.AddWithValue("@stock_product_description1", description.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_product_name1", make_combo.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_quantity1", Convert.ToString(new_stock).ToString());
                cmd.Parameters.AddWithValue("@stock_units1", unit_combo.Text.ToString());
                cmd.ExecuteNonQuery();
                
            }
            else
            {
                dr.Close();

            MySqlCommand cmd = new MySqlCommand("sp_stock", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 1);
            cmd.Parameters.AddWithValue("@stock_id1", null);
            cmd.Parameters.AddWithValue("@stock_product_description1",description.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_product_name1", make_combo.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_quantity1", opening_qty.Text.ToString());
            cmd.Parameters.AddWithValue("@stock_units1", unit_combo.Text.ToString());
            cmd.ExecuteNonQuery();

            }
          
            con.Close();
           }catch(Exception ex )
            {

                MessageBox.Show(ex.Message);    
            }
        }

        private void product_name_TextChanged(object sender, EventArgs e)
        {
            

        }
        private void unitload()
        {
            
        }
        private void unit_TextChanged(object sender, EventArgs e)
        {
             
        }

      

        private void clearAllControl()
        {
            description.ReadOnly = false;
            make_combo.Enabled = true;
            cat_no.ReadOnly = false;
            description.Clear();
            cat_no.Clear();
            make_combo.Text = (" ");
            unit_combo.Text = (" ");
            opening_qty.Clear();
            
        //    unit_combo.SelectedIndex = -1;

          //  make_combo.SelectedIndex = -1;
            remark.Clear();
        }

        private void opening_qty_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if(e.KeyChar>=48 && e.KeyChar<=57||e.KeyChar==8)
            //{
            //    e.Handled = false;
            //}
            //else
            //{
            //    MessageBox.Show("Please Enter only number","Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            //    e.Handled = true;
            //}
        }

        private void updatestock_whenupdate_inward_entry()
        {
             try
            { 

            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd1 = new MySqlCommand("sp_stock", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.AddWithValue("@flag", 12);

            cmd1.Parameters.AddWithValue("@stock_id1", null);
            cmd1.Parameters.AddWithValue("@stock_product_description1",description.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_product_name1",make_combo.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString());
            cmd1.Parameters.AddWithValue("@stock_quantity1", "");
            cmd1.Parameters.AddWithValue("@stock_units1","");

            MySqlDataReader dr = cmd1.ExecuteReader();
            if (dr.Read())             
            {
                present_stock = Convert.ToInt32(dr[4].ToString());
                new_stock = Convert.ToInt32(opening_qty.Text.ToString());
                previous_inward_stock=Convert.ToInt32(store_previous_quantity.Text.ToString());

                if (new_stock>previous_inward_stock)
                {
                    demo = new_stock-previous_inward_stock;
                    present_stock=present_stock + demo;

                }
                else
                {
                    demo = previous_inward_stock-new_stock;
                    present_stock=present_stock  - demo;
                }
                dr.Close();
                MySqlCommand cmd = new MySqlCommand("sp_stock", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 3);
                cmd.Parameters.AddWithValue("@stock_id1", null);
               
                cmd.Parameters.AddWithValue("@stock_product_description1", description.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_product_name1", make_combo.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString());
                cmd.Parameters.AddWithValue("@stock_quantity1", Convert.ToString(present_stock).ToString());
                cmd.Parameters.AddWithValue("@stock_units1", unit_combo.Text.ToString());
                cmd.ExecuteNonQuery();
                
            }
            
          
            con.Close();
           }catch(Exception ex )
            {

                MessageBox.Show(ex.Message);    
            }
        }

        private void read_previous_quantity_before_update()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", 8);
            cmd.Parameters.AddWithValue("@sp_inward_sr_no", Convert.ToInt32(lbl_id.Text.ToString()));
            cmd.Parameters.AddWithValue("@inw_ent_date", "");
            cmd.Parameters.AddWithValue("@inw_ent_time","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_description", "");
            cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_product_name","");
            cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", 0);
            cmd.Parameters.AddWithValue("@sp_inw_ent_unit","");
            cmd.Parameters.AddWithValue("@sp_inw_remark", "");
            MySqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                store_previous_quantity.Text=dr[6].ToString();
                makename=dr[5].ToString();
                catno=dr[4].ToString();
                unitname=dr[7].ToString();

            }

            
        }

        private void read_outvard_entry()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd1 = new MySqlCommand("sp_outward_entry", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.AddWithValue("@flag",9);
            cmd1.Parameters.AddWithValue("@outward_entry_id1", 0);
            cmd1.Parameters.AddWithValue("@out_ent_ProductDesription1", description.Text.ToString().Trim());
            cmd1.Parameters.AddWithValue("@out_ent_ProductName1", make_combo.Text.ToString());
            cmd1.Parameters.AddWithValue("@out_ent_catlogNo1", cat_no.Text.ToString().Trim());
            cmd1.Parameters.AddWithValue("@out_ent_Quantity1", "");
            cmd1.Parameters.AddWithValue("@out_ent_Unit1", "");
            cmd1.Parameters.AddWithValue("@out_ent_Date1", "");
            cmd1.Parameters.AddWithValue("@out_ent_Time1", "");
            cmd1.Parameters.AddWithValue("@out_ent_ChallanNo1", "");
            cmd1.Parameters.AddWithValue("@out_ent_SiteNo1", "");
            cmd1.Parameters.AddWithValue("@out_ent_Remark1", "");
            MySqlDataReader dr = cmd1.ExecuteReader();
            
            if (dr.Read())
            {
                //outward_val1 = Convert.ToInt32(dr[4].ToString());
                label9.Text = dr[0].ToString();
            }
           
            dr.Close();
        }
       private void read_stock_available()
        {
             MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd1 = new MySqlCommand("sp_stock", con);
            cmd1.CommandType = CommandType.StoredProcedure;
            cmd1.Parameters.AddWithValue("@flag",12);
           cmd1.Parameters.AddWithValue("@stock_id1", 0);
           cmd1.Parameters.AddWithValue("@stock_product_description1",description.Text.ToString().Trim());
           cmd1.Parameters.AddWithValue("@stock_product_name1",make_combo.Text.ToString());
           cmd1.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString().Trim());
           cmd1.Parameters.AddWithValue("@stock_quantity1","");
            cmd1.Parameters.AddWithValue("@stock_units1","");

            MySqlDataReader dr = cmd1.ExecuteReader();
           
            if (dr.Read())
            {
                available_stock = Convert.ToInt32(dr[4].ToString());
            }
                dr.Close();

        }

        private void delete_from_stock()
       {
           
           available_stock = available_stock - new_stock;
           MySqlConnection con = new MySqlConnection(str1);
           con.Open();
           MySqlCommand cmd = new MySqlCommand("sp_stock", con);
           cmd.CommandType = CommandType.StoredProcedure;
           cmd.Parameters.AddWithValue("@flag", 3);
           cmd.Parameters.AddWithValue("@stock_id1", null);

           cmd.Parameters.AddWithValue("@stock_product_description1", description.Text.ToString());
           cmd.Parameters.AddWithValue("@stock_product_name1",make_combo.Text.ToString());
           cmd.Parameters.AddWithValue("@stock_catlogNo1", cat_no.Text.ToString());
           cmd.Parameters.AddWithValue("@stock_quantity1", Convert.ToString(available_stock).ToString());
           cmd.Parameters.AddWithValue("@stock_units1", "");
            

           cmd.ExecuteNonQuery();
           con.Close();
       }

        private void unit_combo_SelectedIndexChanged(object sender, EventArgs e)
        {

            cmb_unit_name = unit_combo.SelectedItem as string;
                
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

              
                int index = dataGridView1.CurrentRow.Index; 
                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                lbl_id.Text = selectedRow.Cells[0].Value.ToString();
                date_tb.Text = selectedRow.Cells[1].Value.ToString();
                time_tb.Text = selectedRow.Cells[2].Value.ToString();
                description.Text = selectedRow.Cells[3].Value.ToString();
                cat_no.Text = selectedRow.Cells[4].Value.ToString();
                make_combo.Text = selectedRow.Cells[5].Value.ToString();
                opening_qty.Text = selectedRow.Cells[6].Value.ToString();
                unit_combo.Text = selectedRow.Cells[7].Value.ToString();
                remark.Text = selectedRow.Cells[8].Value.ToString();
                textBox1.Clear();
                
                save.Text = "Update";
                save.Enabled = true;

               
            }
          
          
            if (e.KeyCode == Keys.Delete)
            {
                var confirmResult = MessageBox.Show("Are you sure to delete this item ??",
                                    "Confirm Delete!!",
                                    MessageBoxButtons.YesNo);
                if (confirmResult == DialogResult.Yes)
                {
                    try
                    {
                        if (lbl_id.Text == "")
                        {
                            MessageBox.Show("Select proper entry");
                            return;
                        }
                        MySqlConnection con = new MySqlConnection(str1);
                        con.Open();

                        new_stock = Convert.ToInt32(opening_qty.Text.ToString());
                        read_stock_available();
                        if (available_stock < new_stock)
                        {
                            MessageBox.Show("Already outward Entry goes.You can't delete it");
                            save.Text = "Save";
                        }
                        else
                        {
                            MySqlCommand cmd = new MySqlCommand("sp_inward_entry", con);
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@id", 4);
                            cmd.Parameters.AddWithValue("@sp_inward_sr_no", Convert.ToInt32(lbl_id.Text.ToString()));
                            cmd.Parameters.AddWithValue("@inw_ent_date", date_tb.Text.ToString());
                            cmd.Parameters.AddWithValue("@inw_ent_time", time_tb.Text.ToString());
                            cmd.Parameters.AddWithValue("@sp_inw_ent_description", description.Text.ToString());
                            cmd.Parameters.AddWithValue("@sp_inw_ent_cat_no", cat_no.Text.ToString());
                            cmd.Parameters.AddWithValue("@sp_inw_ent_product_name", make_combo.Text.ToString());
                            cmd.Parameters.AddWithValue("@sp_inw_ent_opening_qty", opening_qty.Text.ToString());
                            cmd.Parameters.AddWithValue("@sp_inw_ent_unit", unit_combo.Text.ToString());
                            cmd.Parameters.AddWithValue("@sp_inw_remark", remark.Text.ToString());

                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Deleted Successfully.....");
                            delete_from_stock();
                            save.Text = "Save";
                        }


                        grid_bind();
                        con.Close();
                        clearAllControl();
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show("Select Proper entry And then Delete it!...");
                    }
                } 

                    }

                    
                else
                { 

            }
               
        }

        private void button3_Click(object sender, EventArgs e)
        {

           
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                // creating new WorkBook within Excel application  
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                // creating new Excelsheet in workbook  
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                // see the excel sheet behind the program  
                app.Visible = true;
                // get the reference of first sheet. By default its name is Sheet1.  
                // store its reference to worksheet  
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                // changing the name of active sheet  
                worksheet.Name = "Exported from gridview";
                // storing header part in Excel  
                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
                }
                // storing Each row and column value to excel sheet  
                for (int i = 0; i <= dataGridView1.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        worksheet.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                    }
                }
          
            SaveFileDialog saveDialog = new SaveFileDialog();
            saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveDialog.FilterIndex = 2;

            if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                workbook.SaveAs(saveDialog.FileName);
                MessageBox.Show("Export Successful");
            }                

        }

        private void make_combo_SelectedValueChanged(object sender, EventArgs e)
        {

            makename = make_combo.SelectedValue.ToString(); 
            
        }

        private void opening_qty_TextChanged(object sender, EventArgs e)
        {

        }

        private void description_TextChanged(object sender, EventArgs e)
        {

        }

        private void make_combo_SelectedIndexChanged(object sender, EventArgs e)
        {

            cmb_make_name= unit_combo.SelectedItem as string;

        }

    }
}
