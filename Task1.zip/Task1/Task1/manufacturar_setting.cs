﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient; 
using System.Windows.Forms;
using System.Text.RegularExpressions; 
using System.Configuration;


namespace Task1
{
    public partial class manufacturar_setting : Form
    {
        string str1 = ConfigurationManager.ConnectionStrings["stock_connect_str"].ConnectionString;
        public manufacturar_setting()
        {
            InitializeComponent();
        }

        private void manufacturar_setting_Load(object sender, EventArgs e)
        {
            grid_bind();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if(menufact_name.Text=="")
            //{
            //    MessageBox.Show("Enter Make Name");
            //}
            //if (!Regex.IsMatch(menufact_name.Text.ToString().Trim(), @"^[a-zA-Z]+$"))
            //{
            //    MessageBox.Show("Please Enter Proper Make Name");
            //    menufact_name.Focus();
            //    return;

            //}
            //else
            //{
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                
              


                if (button1.Text == "Save")
                {
                    MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@flag", 1);
                    cmd.Parameters.AddWithValue("@stock_menufacture_id1", null);
                    cmd.Parameters.AddWithValue("@menu_name1", menufact_name.Text.ToString());

                    MySqlCommand cmd1 = new MySqlCommand("sp_stock_menufacture", con);
                    cmd1.CommandType = CommandType.StoredProcedure;
                    cmd1.Parameters.AddWithValue("@flag", 7);
                    cmd1.Parameters.AddWithValue("@stock_menufacture_id1", null);
                    cmd1.Parameters.AddWithValue("@menu_name1", menufact_name.Text.ToString());

                    int c = 0;
                    MySqlDataReader dr = cmd1.ExecuteReader();
                    while (dr.Read())
                    {
                        if (dr.HasRows == true)
                        {
                            c = 1;
                            MessageBox.Show(" Make Name Already Exist");
                            break;
                        }

                    }
                    dr.Close();
                    if (c == 0)
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Make Name save Successfully");

                    }

                    grid_bind();
                    AllClearControl();
                    con.Close();
                }
                if (button1.Text == "Update")
                {
                   
                    MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@flag", 3);
                    cmd.Parameters.AddWithValue("@stock_menufacture_id1", manufact_id.Text.ToString());
                    cmd.Parameters.AddWithValue("@menu_name1", menufact_name.Text.ToString());
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Update Successfully");
                    grid_bind();
                    AllClearControl();
                    con.Close(); 
                }

                

                button1.Text = "Save";
            //}
           
        }

        private void grid_bind()
        {
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 2);

            cmd.Parameters.AddWithValue("@stock_menufacture_id1", 0);
            cmd.Parameters.AddWithValue("@menu_name1","");

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[0].Visible = false;
            dataGridView1.Columns[1].HeaderText = "Make Name";
            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#00B0B2");
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("ColumnHeadersDefaultCellStyle", 9F, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.BackgroundColor = ColorTranslator.FromHtml("#cefeff");
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = ColorTranslator.FromHtml("#6dfcfe");

            dataGridView1.DefaultCellStyle.ForeColor = Color.Black;
            // Change back color of each row
            // dataGridView1.RowsDefaultCellStyle.BackColor = Color.AliceBlue;
            // Change GridLine Color
            // dataGridView1.GridColor = Color.Blue;
            // Change Grid Border Style
            dataGridView1.BorderStyle = BorderStyle.Fixed3D;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.ReadOnly = true;
            }

            con.Close();

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1 )  // ignore header row and any column
                return;   
            int index = e.RowIndex;
            DataGridViewRow selectedRow = dataGridView1.Rows[index];
            manufact_id.Text = selectedRow.Cells[0].Value.ToString();
           menufact_name.Text = selectedRow.Cells[1].Value.ToString();
           
            
            textBox1.Clear();
            button1.Text = "Update";
            button1.Enabled = true;
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(menufact_name.Text=="")
            {
                MessageBox.Show("Select Make Name Properly From list");
            }
            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 3);
                cmd.Parameters.AddWithValue("@stock_menufacture_id1", manufact_id.Text.ToString());
                cmd.Parameters.AddWithValue("@menu_name1", menufact_name.Text.ToString());
                cmd.ExecuteNonQuery();
                MessageBox.Show("Update Successfully");
                grid_bind();
                AllClearControl();
                con.Close(); 
            }
            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            if (textBox1.Text != "")
            {
                AllClearControl();
                button1.Text = "Save";
                button1.Enabled = false;
                button2.Enabled = true;
            }
            else
            {
                button1.Text = "Save";
                button1.Enabled = true;
                button2.Enabled = true;

            }
            
            
            MySqlConnection con = new MySqlConnection(str1);
            con.Open();
            MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@flag", 5);

            cmd.Parameters.AddWithValue("@stock_menufacture_id1", 0);
            cmd.Parameters.AddWithValue("@menu_name1", textBox1.Text.ToString());

            MySqlDataAdapter sda = new MySqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].HeaderText = "Sr.No.";
            dataGridView1.Columns[1].HeaderText = "Make Name";

            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (menufact_name.Text == "")
            {
                MessageBox.Show("Select Make Name Properly From list");
            }
            else
            {
                MySqlConnection con = new MySqlConnection(str1);
                con.Open();
                MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@flag", 4);
                cmd.Parameters.AddWithValue("@stock_menufacture_id1", manufact_id.Text.ToString());
                cmd.Parameters.AddWithValue("@menu_name1", "");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Delete Successfully");
                grid_bind();
                AllClearControl();
                con.Close();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //this.Close();
            AllClearControl();
            button1.Text = "Save";
        }

        private void AllClearControl()
        {
            menufact_name.Clear();
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                int index = dataGridView1.CurrentRow.Index; ;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];
                manufact_id.Text = selectedRow.Cells[0].Value.ToString();
                menufact_name.Text = selectedRow.Cells[1].Value.ToString();
                textBox1.Clear();
                button1.Text = "Update";
                button1.Enabled = true;
            }
             
             if (e.KeyCode == Keys.Delete)
             {

                 var confirmResult = MessageBox.Show("Are you sure to delete this item ??",
                                      "Confirm Delete!!",
                                      MessageBoxButtons.YesNo);
                 try
                 {
                     if (confirmResult == DialogResult.Yes)
                     {
                         if (manufact_id.Text.ToString() == "")
                         {
                             MessageBox.Show("Select Proper Entry");
                             return;
                         }
                         MySqlConnection con = new MySqlConnection(str1);
                         con.Open();
                         MySqlCommand cmd = new MySqlCommand("sp_stock_menufacture", con);
                         cmd.CommandType = CommandType.StoredProcedure;
                         cmd.Parameters.AddWithValue("@flag", 4);
                         cmd.Parameters.AddWithValue("@stock_menufacture_id1", manufact_id.Text.ToString());
                         cmd.Parameters.AddWithValue("@menu_name1", "");
                         cmd.ExecuteNonQuery();
                         MessageBox.Show("Delete Successfully");
                         grid_bind();
                         AllClearControl();
                         con.Close();
                         button1.Text = "Save";
                     }
                 }
                 catch (Exception ex)
                 {
                     MessageBox.Show("Select Proper entry And then Delete it!...");
                    // MessageBox.Show(ex.Message);
                   
                 }
                 }
                 
                 else
                 {
                     // If 'No', do something here.
                 }

             
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == -1)  // ignore header row and any column
                return;   
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        }
    
}
