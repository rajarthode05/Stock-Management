﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Work;

namespace Task1
{
    public partial class Home : Form
    {
        StreamWriter myStreamWriter;
        StreamReader myStreamReader;
        public Home()
        {
            InitializeComponent();
        }

        private void inwardEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                Stock obj = new Stock();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
          
        }

        private void outboundToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                outward_entry obj = new outward_entry();
                obj.MdiParent = this;
                obj.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                OutWard_History obj = new OutWard_History();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void unitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                Unit_setting obj = new Unit_setting();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void manufacturerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                manufacturar_setting obj = new manufacturar_setting();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void inwardHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                Form1 obj = new Form1();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void historyToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                inward_history obj = new inward_history();
                obj.MdiParent = this;
                obj.Show();

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void importStockDataToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                Import_Stock_Data obj = new Import_Stock_Data();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void registartionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form frm in this.MdiChildren)
            {
                if (!frm.Focused)
                {
                    frm.Visible = false;
                    frm.Dispose();
                }
            }
            try
            {
                Registration obj = new Registration();
                obj.MdiParent = this;
                obj.Show();
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        private void backupToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void restoreToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void backupToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Stock_Backup();
        }
        private void Stock_Backup()
        {
            try
            {
                string file;
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "SQL Dump File(*.sql)|*.sql|All Files(*.*)|*.*";
                sfd.FileName = "Dbbackup.sql";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    file = sfd.FileName;
                    Process myProcess = new Process();
                    myProcess.StartInfo.FileName = "cmd.exe";
                    myProcess.StartInfo.CreateNoWindow = true;
                    myProcess.StartInfo.UseShellExecute = false;
                    myProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                    myProcess.StartInfo.WorkingDirectory = @"C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin\";
                    myProcess.StartInfo.RedirectStandardInput = true;
                    myProcess.StartInfo.RedirectStandardOutput = true;
                    myProcess.Start();
                    myStreamWriter = myProcess.StandardInput;
                    myStreamReader = myProcess.StandardOutput;
                    myStreamWriter.WriteLine("mysqldump -uroot -proot123 stock_db > " + file + "");
                    myStreamWriter.Close();
                    myProcess.WaitForExit();
                    myProcess.Close();
                    MessageBox.Show("Backup done successfully...");




                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database backup failed... ");
            }

        }
        private void restoreToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
            Stock_Restore();
        }
        private void Stock_Restore()
        {
            try
            {
                string file;
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "SQL File(*.sql)|*.sql|All Files(*.*)|*.*";
                ofd.FileName = "";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    file = ofd.FileName;
                    Process myProcess = new Process();
                    myProcess.StartInfo.FileName = "cmd.exe";
                    myProcess.StartInfo.CreateNoWindow = true;
                    myProcess.StartInfo.UseShellExecute = false;

                    myProcess.StartInfo.WorkingDirectory = @"C:\\Program Files\\MySQL\\MySQL Server 8.0\\bin\";
                    myProcess.StartInfo.RedirectStandardInput = true;
                    myProcess.StartInfo.RedirectStandardOutput = true;
                    myProcess.Start();

                    myStreamWriter = myProcess.StandardInput;
                    myStreamReader = myProcess.StandardOutput;
                    myStreamWriter.WriteLine(" mysql -uroot -proot123 stock_db < " + file + "");

                    myStreamWriter.Close();
                    myProcess.WaitForExit();
                    myProcess.Close();
                    MessageBox.Show("Restore done successfully...");




                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Database Restore failed... ");
            }

        }

       

        private void Home_Load(object sender, EventArgs e)
        {
            menuStrip1.Renderer = new BlueRenderer();
        }

        private class BlueRenderer : ToolStripProfessionalRenderer
        {
            protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
            {
                Rectangle rc = new Rectangle(Point.Empty, e.Item.Size);
                Color c = Color.FromArgb(0,176,178);
                using (SolidBrush brush = new SolidBrush(c))
                    e.Graphics.FillRectangle(brush, rc);
            }
        }

    }
}
